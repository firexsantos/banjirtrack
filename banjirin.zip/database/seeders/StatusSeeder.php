<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;
use App\Models\Status;

class StatusSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        $status = new Status;

        $status->alat_id = 1;
        $status->alert_id = 2;
        $status->save();

        $status = new Status;
        $status->alat_id = 2;
        $status->alert_id = 2;
        $status->save();

        $status = new Status;
        $status->alat_id = 3;
        $status->alert_id = 1;
        $status->save();

        $status = new Status;
        $status->alat_id = 4;
        $status->alert_id = 1;
        $status->save();

        $status = new Status;
        $status->alat_id = 5;
        $status->alert_id = 2;
        $status->save();
    }
}
