<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Status;

class Publicdash extends Controller
{
    public function index(){
        return view('publicdash',[
            'title' => 'Banjir Tracking App Kota Pekanbaru',
            'desk' => 'Banjir Tracking App Kota Pekanbaru',
            'keyword' => 'Bajir Tracking, Kota Pekanbaru, Pendeteksi Banjir, Alat Deteksi Banjir, Pemerintah Kota Pekanbaru, Pekanbaru'
        ]);
    }

    public function api(){
		header("Access-Control-Allow-Origin: *");
        $datane = Status::with('alat','alert')->get();
        return response()->json($datane);
        // dd($datane);
    }
}
