<?php

    function identitas($data){
        if($data == "judulweb"){
            return "Pekanbaru Siaga Banjir";
        }
    }
