<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class Status extends Model
{
    use HasFactory;
    public function alat(){
        return $this->belongsTo(Alat::class);
    }

    public function alert(){
        return $this->belongsTo(Alert::class);
    }
}
